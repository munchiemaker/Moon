let IMAGE;
let cnv;
function preload(){
  img = loadImage('moon (1).jpg');

}
//only run once
function setup() {
  cnv= createCanvas(img.width,img.height);
  //print(img.width, img.height)
  let newCanvasX= (windowWidth -img.width)/4;
  let newCanvasY= (windowHeight- img.height)/6;
  cnv.position(newCanvasX, newCanvasY);

  //loopsforever
  for(let col=0;col<img.width;col+=10){
    for(let row=0;row<img.height;row+=10){
      let xPos=col;
      let yPos=row;
      let c= img.get(xPos,yPos);
      //fill(color(c));
      push();
      translate(xPos,yPos);
      rotate(radians(random(360)))
      noFill();
      strokeWeight (random(5));
      stroke(color(c));
      //point(col,row);
      //rect(col,row,10,8)
      curve(xPos, yPos, sin(xPos)*random(45), cos(yPos)*sin(xPos)*random(69),random
(10),random(25),random(40), cos(yPos)*sin(xPos)*50)
      pop();
    }
    
}
 
}